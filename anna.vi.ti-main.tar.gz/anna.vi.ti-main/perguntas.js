criaCartao(
    'matematica',
    'Quanto é 9x8?',
    'A resposta é 72'
)

criaCartao(
    'Geografia',
    'Qual a capital do Japão?',
    'A capital do Japão é Tóquio'
)

criaCartao(
    'biologia',
    'Qual é a ação que a planta faz pra se alimentar?',
    'fotossintese'
)

criaCartao(
    'Lingua inglesa',
    'Como se diz Maçã em Inglês?',
    'Maçã em ingles é Apple)'
)